fun main(args: Array<String>) {
    val N = readLine()!!.toInt()
    for (i in 0..10) println("$N x $i = ${N * i}")
}
