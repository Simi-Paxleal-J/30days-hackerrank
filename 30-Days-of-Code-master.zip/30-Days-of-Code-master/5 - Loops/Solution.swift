let N = Int(readLine()!)!

for i in 1 ... 10 {
    print("\(N) x \(i) = \(N * i)");
}
