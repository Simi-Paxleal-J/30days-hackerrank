my $ii = $i + <STDIN>; 
my $dd = sprintf("%.1f", $d + <STDIN>); 
my $ss = <STDIN>; 

print "$ii\n";
print "$dd\n";
print "$s$ss\n";
