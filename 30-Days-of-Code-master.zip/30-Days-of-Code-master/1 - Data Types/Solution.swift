var i = 4
var d = 4.0
var s = "HackerRank "

// Declare second integer, double, and String variables.
var i2: Int
var d2: Double
var s2: String

// Read and save an integer, double, and String to your variables.
i2 = Int(readLine()!)!
d2 = Double(readLine()!)!
s2 = readLine()!

// Print the sum of both integer variables on a new line.
print(i + i2)

// Print the sum of the double variables on a new line.
print(d + d2)

// Concatenate and print the String variables on a new line
// The 's' variable above should be printed first.
print(s + s2)
