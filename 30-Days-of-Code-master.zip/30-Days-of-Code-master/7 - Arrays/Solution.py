input()

arr = str(input()).split(" ")
arr.reverse()

for num in arr:
    print(num + " ", end="")
