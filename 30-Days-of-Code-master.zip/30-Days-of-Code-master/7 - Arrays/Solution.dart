void main() { 
   var num_list = [1,2,3]; 
   print(num_list); 
   
   var lst = new List(); 
   lst.add(12); 
   lst.add(13); 
   print(lst); 
}
