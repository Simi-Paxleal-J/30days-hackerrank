class Solution {
    fun main(srgs: Array<String>) {
        println(5)
        println("4 3")
        println("0 -3 4 2")
        println("5 2")
        println("0 -3 4 2 2")
        println("3 3")
        println("0 -3 4")
        println("7 2")
        println("0 -3 1 1 1 1 1")
        println("6 3")
        println("0 -3 4 2 1 1")
    }
}
