class Solution {
    public static void main(String srgs[]) {
        System.out.println(5);
        System.out.println("4 3");
        System.out.println("0 -3 4 2");
        System.out.println("5 2");
        System.out.println("0 -3 4 2 2");
        System.out.println("3 3");
        System.out.println("0 -3 4");
        System.out.println("7 2");
        System.out.println("0 -3 1 1 1 1 1");
        System.out.println("6 3");
        System.out.println("0 -3 4 2 1 1");
    }
}
