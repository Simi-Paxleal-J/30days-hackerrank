object Solution {
    def main(args: Array[String]) {
        val inputString = scala.io.StdIn.readLine()
        println("Hello, World.")
        println(inputString)
    }
}
