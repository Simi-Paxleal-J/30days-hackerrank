fun main(args: Array<String>) {
    val str = readLine()
    println("Hello, World.")
    println(str)
}
