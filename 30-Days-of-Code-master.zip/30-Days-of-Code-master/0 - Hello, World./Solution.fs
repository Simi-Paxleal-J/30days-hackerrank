open System

[<EntryPoint>]
let main argv = 
    printfn "Hello, World."
    Console.ReadLine() |> Console.WriteLine
    0
