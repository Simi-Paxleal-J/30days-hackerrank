; Enter your code here. Read input from STDIN. Print output to STDOUT
;
(def inputString (read-line))
(println "Hello, World.")
(println inputString)
